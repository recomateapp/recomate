import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_web_view.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'web_test_model.dart';
export 'web_test_model.dart';

class WebTestWidget extends StatefulWidget {
  const WebTestWidget({super.key});

  @override
  State<WebTestWidget> createState() => _WebTestWidgetState();
}

class _WebTestWidgetState extends State<WebTestWidget> {
  late WebTestModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => WebTestModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(),
        child: FlutterFlowWebView(
          content: 'https://www.recomate.app/',
          bypass: false,
          height: MediaQuery.sizeOf(context).height * 1.0,
          verticalScroll: false,
          horizontalScroll: false,
        ),
      ),
    );
  }
}
