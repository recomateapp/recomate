import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const String versionNumber = 'v1';
  static const List<String> countriesList = ['USA', 'Netherlands', 'Canada'];
}
