import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/back_icon_button_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'about_you_widget.dart' show AboutYouWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AboutYouModel extends FlutterFlowModel<AboutYouWidget> {
  ///  Local state fields for this page.

  List<String> pageCountries = [];
  void addToPageCountries(String item) => pageCountries.add(item);
  void removeFromPageCountries(String item) => pageCountries.remove(item);
  void removeAtIndexFromPageCountries(int index) =>
      pageCountries.removeAt(index);
  void insertAtIndexInPageCountries(int index, String item) =>
      pageCountries.insert(index, item);
  void updatePageCountriesAtIndex(int index, Function(String) updateFn) =>
      pageCountries[index] = updateFn(pageCountries[index]);

  bool profilePicUploaded = false;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (getCountries)] action in about_you widget.
  ApiCallResponse? getCountriesResp;
  // Model for back_icon_button component.
  late BackIconButtonModel backIconButtonModel;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for name widget.
  FocusNode? nameFocusNode;
  TextEditingController? nameTextController;
  String? Function(BuildContext, String?)? nameTextControllerValidator;
  DateTime? datePicked;
  // State field(s) for genderDropD widget.
  String? genderDropDValue;
  FormFieldController<String>? genderDropDValueController;
  // State field(s) for countryDropD widget.
  String? countryDropDValue;
  FormFieldController<String>? countryDropDValueController;
  // State field(s) for relationshipD widget.
  String? relationshipDValue;
  FormFieldController<String>? relationshipDValueController;

  @override
  void initState(BuildContext context) {
    backIconButtonModel = createModel(context, () => BackIconButtonModel());
  }

  @override
  void dispose() {
    backIconButtonModel.dispose();
    nameFocusNode?.dispose();
    nameTextController?.dispose();
  }
}
