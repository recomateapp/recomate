import '/components/back_icon_button_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'otp_confirmation_success_screen_widget.dart'
    show OtpConfirmationSuccessScreenWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class OtpConfirmationSuccessScreenModel
    extends FlutterFlowModel<OtpConfirmationSuccessScreenWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for back_icon_button component.
  late BackIconButtonModel backIconButtonModel;

  @override
  void initState(BuildContext context) {
    backIconButtonModel = createModel(context, () => BackIconButtonModel());
  }

  @override
  void dispose() {
    backIconButtonModel.dispose();
  }
}
