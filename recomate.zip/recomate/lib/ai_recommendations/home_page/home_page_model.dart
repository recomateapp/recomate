import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'home_page_widget.dart' show HomePageWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  Local state fields for this page.

  String location = 'nil';

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (GeoCodeReverse)] action in home_page widget.
  ApiCallResponse? locationResp;
  // Stores action output result for [Firestore Query - Query a collection] action in home_page widget.
  QuestionRecord? activityResp;
  // Stores action output result for [Firestore Query - Query a collection] action in home_page widget.
  QuestionRecord? foodResp;
  // Stores action output result for [Firestore Query - Query a collection] action in home_page widget.
  QuestionRecord? movieResp;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
