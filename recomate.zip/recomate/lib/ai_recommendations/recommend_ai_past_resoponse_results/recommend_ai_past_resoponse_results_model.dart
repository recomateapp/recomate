import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'recommend_ai_past_resoponse_results_widget.dart'
    show RecommendAiPastResoponseResultsWidget;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RecommendAiPastResoponseResultsModel
    extends FlutterFlowModel<RecommendAiPastResoponseResultsWidget> {
  ///  Local state fields for this page.

  List<dynamic> aiResponse = [];
  void addToAiResponse(dynamic item) => aiResponse.add(item);
  void removeFromAiResponse(dynamic item) => aiResponse.remove(item);
  void removeAtIndexFromAiResponse(int index) => aiResponse.removeAt(index);
  void insertAtIndexInAiResponse(int index, dynamic item) =>
      aiResponse.insert(index, item);
  void updateAiResponseAtIndex(int index, Function(dynamic) updateFn) =>
      aiResponse[index] = updateFn(aiResponse[index]);

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
