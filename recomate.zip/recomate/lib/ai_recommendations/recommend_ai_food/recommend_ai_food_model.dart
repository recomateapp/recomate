import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/components/back_icon_button_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'recommend_ai_food_widget.dart' show RecommendAiFoodWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';

class RecommendAiFoodModel extends FlutterFlowModel<RecommendAiFoodWidget> {
  ///  Local state fields for this page.

  int currentQuestionIndex = 0;

  List<dynamic> userResponses = [];
  void addToUserResponses(dynamic item) => userResponses.add(item);
  void removeFromUserResponses(dynamic item) => userResponses.remove(item);
  void removeAtIndexFromUserResponses(int index) =>
      userResponses.removeAt(index);
  void insertAtIndexInUserResponses(int index, dynamic item) =>
      userResponses.insert(index, item);
  void updateUserResponsesAtIndex(int index, Function(dynamic) updateFn) =>
      userResponses[index] = updateFn(userResponses[index]);

  bool aiLoading = false;

  ///  State fields for stateful widgets in this page.

  // State field(s) for mainList widget.
  ScrollController? mainList;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  List<String>? get choiceChipsValues => choiceChipsValueController?.value;
  set choiceChipsValues(List<String>? val) =>
      choiceChipsValueController?.value = val;
  // State field(s) for ListView widget.
  ScrollController? listViewController;
  // Stores action output result for [Backend Call - API (chatCompletion)] action in Image widget.
  ApiCallResponse? aiResp;
  // Stores action output result for [Backend Call - Create Document] action in Image widget.
  UserAiHistoryRecord? historyResp;

  @override
  void initState(BuildContext context) {
    mainList = ScrollController();
    listViewController = ScrollController();
  }

  @override
  void dispose() {
    mainList?.dispose();
    listViewController?.dispose();
  }
}
