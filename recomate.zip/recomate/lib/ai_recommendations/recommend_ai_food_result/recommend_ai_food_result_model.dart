import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'recommend_ai_food_result_widget.dart' show RecommendAiFoodResultWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RecommendAiFoodResultModel
    extends FlutterFlowModel<RecommendAiFoodResultWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
