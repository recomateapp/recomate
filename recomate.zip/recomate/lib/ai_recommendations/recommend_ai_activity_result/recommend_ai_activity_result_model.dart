import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'recommend_ai_activity_result_widget.dart'
    show RecommendAiActivityResultWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RecommendAiActivityResultModel
    extends FlutterFlowModel<RecommendAiActivityResultWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
