import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_web_view.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'privacy_polices_widget.dart' show PrivacyPolicesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PrivacyPolicesModel extends FlutterFlowModel<PrivacyPolicesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
