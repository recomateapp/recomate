import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'back_icon_button_widget.dart' show BackIconButtonWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BackIconButtonModel extends FlutterFlowModel<BackIconButtonWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
